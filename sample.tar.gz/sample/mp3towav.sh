#!/bin/bash

folder=~/myexperiment/samples/wav

for file in $(find "$folder" -type f -iname "*.mp3")
do
    name=$(basename "$file" .flac)
    dir=$(dirname "$file")
    echo ffmpeg -i "$file" -acodec pcm_s16le -ac 1 -ar 16000 "$dir"/"$name".wav
    ffmpeg -i "$file" -acodec pcm_s16le -ac 1 -ar 16000 "$dir"/"$name".wav
    
done
find .mp3|xargs rm -rf
